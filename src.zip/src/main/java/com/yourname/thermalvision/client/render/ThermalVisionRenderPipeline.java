package com.yourname.thermalvision.client.render;

import com.mojang.blaze3d.pipeline.RenderTarget;
import com.mojang.blaze3d.pipeline.TextureTarget;
import com.mojang.blaze3d.platform.GlStateManager;
import com.yourname.thermalvision.client.ClientThermalVisionState;
import com.yourname.thermalvision.client.ThermalVisionPostProcessor;
import java.io.IOException;
import java.util.ArrayDeque;
import java.util.Deque;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.PostChain;
import net.minecraft.client.renderer.PostPass;
import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.client.event.RenderLevelStageEvent;
import org.lwjgl.opengl.GL11;
import org.lwjgl.opengl.GL30;

public final class ThermalVisionRenderPipeline {
    private static final ResourceLocation COMPOSITE_PIPELINE =
        new ResourceLocation("thermal_vision", "shaders/post/thermal_entity_composite_pipeline.json");
    private static final String SCENE_COPY_TARGET = "thermal_scene_copy";

    private static final Deque<FramebufferBinding> FRAMEBUFFER_STACK = new ArrayDeque<>();

    private static TextureTarget maskTarget;
    private static PostChain compositeChain;
    private static PostPass compositePass;
    private static int targetWidth = -1;
    private static int targetHeight = -1;
    private static boolean framePrepared;
    private static boolean failed;

    private ThermalVisionRenderPipeline() {
    }

    public static void prepareFrame(RenderLevelStageEvent event) {
        if (event.getStage() != RenderLevelStageEvent.Stage.AFTER_CUTOUT_BLOCKS) {
            return;
        }

        restoreLeakedFramebufferBindings("the start of a new frame");

        if (!shouldRenderMask()) {
            framePrepared = false;
            return;
        }

        Minecraft minecraft = Minecraft.getInstance();
        if (minecraft.level == null || minecraft.player == null || failed) {
            framePrepared = false;
            return;
        }

        RenderTarget mainTarget = minecraft.getMainRenderTarget();
        FramebufferBinding binding = captureFramebufferBinding();

        try {
            ensureTargets(minecraft, mainTarget.width, mainTarget.height);

            maskTarget.setClearColor(0.0F, 0.0F, 0.0F, 0.0F);
            maskTarget.clear(Minecraft.ON_OSX);
            maskTarget.copyDepthFrom(mainTarget);

            framePrepared = true;
        } catch (IOException | RuntimeException exception) {
            failed = true;
            framePrepared = false;
            ThermalVisionRenderLog.error(
                "Failed to prepare thermal entity mask pipeline " + describeFramebufferState(),
                exception
            );
            destroyTargets();
        } finally {
            restoreFramebufferBinding(binding);
        }
    }

    public static void composite(float partialTick) {
        restoreLeakedFramebufferBindings("the entity-mask composite pass");

        if (!framePrepared
            || maskTarget == null
            || compositeChain == null
            || failed) {
            return;
        }

        FramebufferBinding binding = captureFramebufferBinding();

        try {
            compositeChain.process(partialTick);
        } catch (RuntimeException exception) {
            failed = true;
            ThermalVisionRenderLog.error(
                "Failed to composite thermal entity mask " + describeFramebufferState(),
                exception
            );
            destroyTargets();
        } finally {
            framePrepared = false;
            restoreFramebufferBinding(binding);
        }
    }

    public static boolean isMaskRenderingEnabled() {
        return framePrepared
            && maskTarget != null
            && ThermalVisionShaders.getEntityMaskShader() != null
            && shouldRenderMask();
    }

    public static void bindMaskTarget() {
        if (!isMaskRenderingEnabled()) {
            return;
        }

        FramebufferBinding binding = captureFramebufferBinding();
        try {
            maskTarget.bindWrite(false);
            FRAMEBUFFER_STACK.push(binding);
        } catch (RuntimeException exception) {
            restoreFramebufferBinding(binding);
            ThermalVisionRenderLog.error(
                "Failed to bind thermal entity mask target " + describeFramebufferState(),
                exception
            );
            throw exception;
        }
    }

    public static void restorePreviousTarget() {
        if (!FRAMEBUFFER_STACK.isEmpty()) {
            restoreFramebufferBinding(FRAMEBUFFER_STACK.pop());
        }
    }

    public static void reset() {
        framePrepared = false;
        failed = false;
        restoreLeakedFramebufferBindings("the thermal pipeline reset");

        FramebufferBinding binding = captureFramebufferBinding();
        try {
            destroyTargets();
        } finally {
            restoreFramebufferBinding(binding);
        }
    }

    public static void onResourceReload() {
        reset();
        ThermalVisionRenderLog.debug(
            "Invalidated thermal entity mask targets after client resource reload"
        );
    }

    private static boolean shouldRenderMask() {
        return ClientThermalVisionState.isActive()
            || ThermalVisionPostProcessor.effectStrength() > 0.001F;
    }

    private static void ensureTargets(Minecraft minecraft, int width, int height) throws IOException {
        boolean sizeChanged = width != targetWidth || height != targetHeight;

        if (maskTarget == null) {
            maskTarget = new TextureTarget(width, height, true, Minecraft.ON_OSX);
            targetWidth = width;
            targetHeight = height;
            sizeChanged = true;
        } else if (sizeChanged) {
            maskTarget.resize(width, height, Minecraft.ON_OSX);
            targetWidth = width;
            targetHeight = height;
        }

        if (sizeChanged && compositeChain != null) {
            compositeChain.close();
            compositeChain = null;
            compositePass = null;
        }

        if (compositeChain == null) {
            compositeChain = new PostChain(
                minecraft.getTextureManager(),
                minecraft.getResourceManager(),
                minecraft.getMainRenderTarget(),
                COMPOSITE_PIPELINE
            );
            compositeChain.addTempTarget(SCENE_COPY_TARGET, width, height);

            RenderTarget sceneCopy = compositeChain.getTempTarget(SCENE_COPY_TARGET);
            compositeChain.addPass("blit", minecraft.getMainRenderTarget(), sceneCopy);
            compositePass = compositeChain.addPass(
                "thermal_vision:thermal_entity_composite",
                sceneCopy,
                minecraft.getMainRenderTarget()
            );
            compositePass.addAuxAsset(
                "ThermalMaskSampler",
                maskTarget::getColorTextureId,
                width,
                height
            );
        }

        compositeChain.resize(width, height);
    }

    private static void destroyTargets() {
        if (compositeChain != null) {
            compositeChain.close();
            compositeChain = null;
            compositePass = null;
        }

        if (maskTarget != null) {
            maskTarget.destroyBuffers();
            maskTarget = null;
        }

        targetWidth = -1;
        targetHeight = -1;
    }

    private static void restoreLeakedFramebufferBindings(String context) {
        if (FRAMEBUFFER_STACK.isEmpty()) {
            return;
        }

        int leakedBindings = FRAMEBUFFER_STACK.size();
        while (!FRAMEBUFFER_STACK.isEmpty()) {
            restoreFramebufferBinding(FRAMEBUFFER_STACK.pop());
        }

        ThermalVisionRenderLog.warn(
            "Recovered {} leaked thermal framebuffer binding(s) before {}",
            leakedBindings,
            context
        );
    }

    private static String describeFramebufferState() {
        FramebufferBinding binding = captureFramebufferBinding();
        int maskFramebuffer = maskTarget == null ? -1 : maskTarget.frameBufferId;

        return "[draw=" + binding.drawFramebuffer()
            + ", read=" + binding.readFramebuffer()
            + ", mask=" + maskFramebuffer
            + ", size=" + targetWidth + "x" + targetHeight + "]";
    }

    private static FramebufferBinding captureFramebufferBinding() {
        return new FramebufferBinding(
            GL11.glGetInteger(GL30.GL_DRAW_FRAMEBUFFER_BINDING),
            GL11.glGetInteger(GL30.GL_READ_FRAMEBUFFER_BINDING)
        );
    }

    private static void restoreFramebufferBinding(FramebufferBinding binding) {
        GlStateManager._glBindFramebuffer(GL30.GL_DRAW_FRAMEBUFFER, binding.drawFramebuffer());
        GlStateManager._glBindFramebuffer(GL30.GL_READ_FRAMEBUFFER, binding.readFramebuffer());
    }

    private record FramebufferBinding(int drawFramebuffer, int readFramebuffer) {
    }
}
